import os
from http.server import SimpleHTTPRequestHandler, HTTPServer
import cgi
import mysql.connector

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="your_username",  
        password="your_password",  
        database="techsparks"
    )

class IdeaSubmissionHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/":
            self.path = "form.html" 
        elif self.path == "/admin":
            self.show_admin_view()  
            return
        return super().do_GET()

    def do_POST(self):
        if self.path == "/submit":
            self.handle_submission()
        else:
            self.send_error(404, "Not Found")

    def handle_submission(self):
        form = cgi.FieldStorage(fp=self.rfile, headers=self.headers, environ={'REQUEST_METHOD': 'POST'})
        
        name = form.getvalue("name")
        email = form.getvalue("email")
        idea = form.getvalue("idea")
        photo_file = form["photo"]
        
        photo_path = None
        if photo_file.filename:
            photo_path = os.path.join(UPLOAD_FOLDER, photo_file.filename)
            with open(photo_path, "wb") as file:
                file.write(photo_file.file.read())

      
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO submissions (name, email, idea, photo_path) VALUES (%s, %s, %s, %s)",
                       (name, email, idea, photo_path))
        conn.commit()
        conn.close()

      
        self.send_response(302)
        self.send_header("Location", "/admin")
        self.end_headers()

    def show_admin_view(self):
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM submissions")
        submissions = cursor.fetchall()
        conn.close()

        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()

        html = """
        <html>
        <head>
            <title>Admin View</title>
            <style>
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #ddd; padding: 8px; }
                th { background-color: #f4f4f4; }
                img { max-width: 100px; max-height: 100px; }
            </style>
        </head>
        <body>
            <h1>Submitted Ideas</h1>
            <table>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Idea</th>
                    <th>Photo</th>
                </tr>
        """
        for submission in submissions:
            html += f"""
                <tr>
                    <td>{submission['name']}</td>
                    <td>{submission['email']}</td>
                    <td>{submission['idea']}</td>
                    <td>
                        {'<img src="' + submission['photo_path'] + '">' if submission['photo_path'] else 'No Photo'}
                    </td>
                </tr>
            """
        html += """
            </table>
        </body>
        </html>
        """
        self.wfile.write(html.encode("utf-8"))


if __name__ == "__main__":
    PORT = 8080
    with HTTPServer(("localhost", PORT), IdeaSubmissionHandler) as server:
        print(f"Server running on http://localhost:{PORT}")
        server.serve_forever()
