CREATE DATABASE techsparks;
USE techsparks;

CREATE TABLE submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    idea TEXT NOT NULL,
    photo_path VARCHAR(255)
);
